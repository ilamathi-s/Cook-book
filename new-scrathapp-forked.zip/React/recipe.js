const recipe = [
  {
    key=1,
    title: "Chicken Curry",
    image: "",
    description:
      "A flavorful and spicy chicken dish made with a blend of spices and coconut milk",
  },
  {
    key=2,
    title: "Chocolate Cake",
    image: "",
    description: "A rich and moist chocolate cake perfect for dessert lovers.",
  },
  {
    key=3,
    title: "Margherita Pizza",
    image: "",
    description:
      "A simple pizza topped with fresh tomatoes, mozzarella cheese, and basil",
  },
  {
    key=4,
    title: "Onion Soup",
    image: "",
    description:
      "A rich and savory soup made with carmelized onions and topped with cheese.",
  },
  {
    key=5,
    title: "Veg Stir Fry",
    image: "",
    description:
      "A quick and easy stir-frymade with a variety of fresh vegetables and savory sauce.",
  },
];
export default recipe;
