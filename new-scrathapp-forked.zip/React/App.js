import React from "react";
import recipe from "./Recipes";
import Recipes from "./recipe";
import "./style.css";

function App() {
  return (
    <div classname="list">
      {Recipes.map((Recipe) => (
        <Recipes
          key={Recipe.key}
          title={Recipe.title}
          image={Recipe.image}
          description={Recipe.description}
        />
      ))}
    </div>
  );
}
export default App;
