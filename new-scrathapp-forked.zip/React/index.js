import React from "react";
import React-DOM from "react-dom";
import app from "./App";
import style from "./style.css";
ReactDOM.render(<App/>, document.getElementById('root'));