import React from "react";
function Recipes(props) {
  return (
    <div classname="card">
      <h1>{props.title}</h1>
      <img src={props.image} c>
        {" "}
      </img>
      <p>{props.description}</p>
    </div>
  );
}
export default Recipes;
