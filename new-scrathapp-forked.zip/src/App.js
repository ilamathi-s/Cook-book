import React from "react";
import Recipes from "./Recipes";
import recipe from "./recipe";
import "./style.css";

function App() {
  return (
    <div className="list">
      {recipe.map((Recipe) => (
        <Recipes
          key={Recipe.key}
          title={Recipe.title}
          image={Recipe.image}
          description={Recipe.description}
        />
      ))}
    </div>
  );
}

export default App;
