import React from "react";

function Recipes(props) {
  return (
    <div className="card">
      <h1>{props.title}</h1>
      <img src={props.image} className="recipe-image" />
      <p>{props.description}</p>
    </div>
  );
}

export default Recipes;
