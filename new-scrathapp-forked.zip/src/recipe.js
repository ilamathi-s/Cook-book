const recipe = [
  {
    key: 1,
    title: "Chicken Curry",
    image:
      "https://t3.ftcdn.net/jpg/01/64/41/20/360_F_164412070_kZoPXrGd6AXwbLhXEIQulcbeU5xU6hdh.jpg",
    description:
      "A flavorful and spicy chicken dish made with a blend of spices and coconut milk",
  },
  {
    key: 2,
    title: "Chocolate Cake",
    image:
      "https://mrbrownbakery.com/image/images/GJ7uCwGiteTF24HTWBclkziVTdhpQeZWH23MvQfq.jpeg?p=full",
    description: "A rich and moist chocolate cake perfect for dessert lovers.",
  },
  {
    key: 3,
    title: "Margherita Pizza",
    image:
      "https://www.jocooks.com/wp-content/uploads/2012/03/margherita-pizza-11.jpg",
    description:
      "A simple pizza topped with fresh tomatoes, mozzarella cheese, and basil",
  },
  {
    key: 4,
    title: "Veg Soup",
    image:
      "https://t3.ftcdn.net/jpg/02/45/00/72/360_F_245007231_vDwC9ceDNtjUCA5YDuq6mPDRG5ocPg0B.jpg",
    description: "A rich and savory soup made with fried vegetables.",
  },
  {
    key: 5,
    title: "Fried Rice",
    image:
      "https://www.kannammacooks.com/wp-content/uploads/schezwan-veg-fried-rice-1.jpg",
    description:
      "A quick and easy made with a variety of fresh vegetables and savory sauces to make the rice more delicious.",
  },
];
export default recipe;
